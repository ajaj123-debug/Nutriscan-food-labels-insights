from django.apps import AppConfig


class OcrAppPr1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ocr_app_pr1'
